import { motion } from 'framer-motion';
import { X, ShoppingBag, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';

interface CartPreviewProps {
  onClose: () => void;
}

const CartPreview: React.FC<CartPreviewProps> = ({ onClose }) => {
  const { cart, removeFromCart, updateQuantity, subtotal } = useCart();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleCheckout = async () => {
    setIsProcessing(true);
    
    try {
      const stripe = await loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);
      
      if (!stripe) {
        throw new Error('Stripe failed to load');
      }

      // Create a checkout session
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ items: cart }),
      });

      const session = await response.json();

      // Redirect to Stripe checkout
      const result = await stripe.redirectToCheckout({
        sessionId: session.id,
      });

      if (result.error) {
        throw new Error(result.error.message);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Failed to initiate checkout. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black bg-opacity-50 flex justify-end"
      onClick={onClose}
    >
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'tween', duration: 0.3 }}
        className="bg-white w-full max-w-md h-full overflow-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 h-full flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold">Your Cart</h2>
            <button 
              className="p-2 text-gray-500 hover:text-gray-700 transition-colors"
              onClick={onClose}
              aria-label="Close cart"
            >
              <X size={20} />
            </button>
          </div>

          {cart.length === 0 ? (
            <div className="flex-grow flex flex-col items-center justify-center">
              <ShoppingBag size={64} className="text-gray-300 mb-4" />
              <p className="text-gray-500 mb-4">Your cart is empty</p>
              <Link 
                to="/shop" 
                className="bg-primary-600 text-white px-6 py-2 rounded-md hover:bg-primary-700 transition-colors"
                onClick={onClose}
              >
                Start Shopping
              </Link>
            </div>
          ) : (
            <>
              <div className="flex-grow overflow-auto mb-6">
                {cart.map((item) => (
                  <div 
                    key={`${item.product.id}-${item.size}`} 
                    className="flex py-4 border-b border-gray-200"
                  >
                    <img 
                      src={item.product.images[0]} 
                      alt={item.product.name} 
                      className="w-20 h-20 object-cover rounded-md mr-4"
                    />
                    <div className="flex-grow">
                      <h3 className="font-medium">{item.product.name}</h3>
                      <p className="text-sm text-gray-500">Size: {item.size}</p>
                      <div className="flex justify-between items-center mt-2">
                        <div className="flex items-center">
                          <button 
                            className="w-6 h-6 bg-gray-100 flex items-center justify-center rounded"
                            onClick={() => updateQuantity(item.product.id, item.size, Math.max(1, item.quantity - 1))}
                            aria-label="Decrease quantity"
                          >
                            -
                          </button>
                          <span className="mx-2 min-w-[20px] text-center">{item.quantity}</span>
                          <button 
                            className="w-6 h-6 bg-gray-100 flex items-center justify-center rounded"
                            onClick={() => updateQuantity(item.product.id, item.size, item.quantity + 1)}
                            aria-label="Increase quantity"
                          >
                            +
                          </button>
                        </div>
                        <div className="flex items-center">
                          <span className="font-medium mr-3">
                            ${(item.product.price * item.quantity).toFixed(2)}
                          </span>
                          <button 
                            className="text-gray-400 hover:text-red-500 transition-colors"
                            onClick={() => removeFromCart(item.product.id, item.size)}
                            aria-label="Remove item"
                          >
                            <X size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="pt-4 border-t border-gray-200">
                <div className="flex justify-between mb-4">
                  <span className="font-medium">Subtotal</span>
                  <span className="font-semibold">${subtotal.toFixed(2)}</span>
                </div>
                <p className="text-sm text-gray-500 mb-4">
                  Shipping and taxes calculated at checkout
                </p>
                <button 
                  className="w-full bg-primary-600 text-white py-3 rounded-md font-medium hover:bg-primary-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
                  onClick={handleCheckout}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 size={20} className="animate-spin mr-2" />
                      Processing...
                    </>
                  ) : (
                    'Proceed to Checkout'
                  )}
                </button>
                <button 
                  className="w-full mt-3 bg-white text-primary-600 border border-primary-600 py-3 rounded-md font-medium hover:bg-primary-50 transition-colors"
                  onClick={onClose}
                >
                  Continue Shopping
                </button>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default CartPreview;