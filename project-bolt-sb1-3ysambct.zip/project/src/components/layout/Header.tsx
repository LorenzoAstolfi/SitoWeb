import { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, ShoppingBag, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

import CartPreview from '../cart/CartPreview';
import { useCart } from '../../context/CartContext';

interface HeaderProps {
  scrolled: boolean;
}

const Header: React.FC<HeaderProps> = ({ scrolled }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { itemCount } = useCart();
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
    if (!isMenuOpen) setIsCartOpen(false);
  };

  const toggleCart = () => {
    setIsCartOpen(!isCartOpen);
    if (!isCartOpen) setIsMenuOpen(false);
  };

  const closeAll = () => {
    setIsMenuOpen(false);
    setIsCartOpen(false);
  };

  useEffect(() => {
    closeAll();
  }, [location]);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center group" onClick={closeAll}>
            <span className="text-2xl font-heading font-bold bg-gradient-to-r from-primary-600 to-primary-800 bg-clip-text text-transparent transition-all duration-300 group-hover:tracking-wider">
              Hubb
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {[
              { path: '/', label: 'Home' },
              { path: '/shop', label: 'Shop' },
              { path: '/about', label: 'About' },
              { path: '/contact', label: 'Contact' }
            ].map(({ path, label }) => (
              <NavLink
                key={path}
                to={path}
                className={({ isActive }) => `
                  relative px-4 py-2 font-medium transition-colors
                  ${scrolled 
                    ? isActive ? 'text-primary-600' : 'text-gray-700 hover:text-primary-600' 
                    : isActive ? 'text-primary-600' : 'text-gray-800 hover:text-primary-600'
                  }
                  before:content-[''] before:absolute before:bottom-0 before:left-0 before:w-full before:h-0.5
                  before:bg-primary-600 before:transform before:scale-x-0 before:origin-right
                  before:transition-transform before:duration-300
                  hover:before:scale-x-100 hover:before:origin-left
                  ${isActive ? 'before:scale-x-100' : ''}
                `}
              >
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            {/* Cart Icon */}
            <button 
              className="relative p-2 text-gray-700 hover:text-primary-600 transition-colors"
              onClick={toggleCart}
              aria-label="Shopping cart"
            >
              <ShoppingBag size={22} className="transition-transform duration-300 hover:scale-110" />
              {itemCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 bg-primary-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center"
                >
                  {itemCount}
                </motion.span>
              )}
            </button>

            {/* Mobile Menu Button */}
            <button 
              className="p-2 text-gray-700 hover:text-primary-600 md:hidden transition-colors"
              onClick={toggleMenu}
              aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
            >
              <motion.div
                animate={{ rotate: isMenuOpen ? 90 : 0 }}
                transition={{ duration: 0.2 }}
              >
                {isMenuOpen ? <X size={22} /> : <Menu size={22} />}
              </motion.div>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="md:hidden overflow-hidden bg-white/95 backdrop-blur-md mt-4 rounded-lg"
            >
              <nav className="flex flex-col p-4 space-y-2">
                {[
                  { path: '/', label: 'Home' },
                  { path: '/shop', label: 'Shop' },
                  { path: '/about', label: 'About' },
                  { path: '/contact', label: 'Contact' }
                ].map(({ path, label }) => (
                  <NavLink
                    key={path}
                    to={path}
                    onClick={closeAll}
                    className={({ isActive }) => `
                      px-4 py-2 rounded-md font-medium transition-all duration-300
                      ${isActive 
                        ? 'bg-primary-50 text-primary-600' 
                        : 'text-gray-700 hover:bg-gray-50 hover:text-primary-600'
                      }
                    `}
                  >
                    {label}
                  </NavLink>
                ))}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Cart Preview */}
      <AnimatePresence>
        {isCartOpen && (
          <CartPreview onClose={() => setIsCartOpen(false)} />
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;