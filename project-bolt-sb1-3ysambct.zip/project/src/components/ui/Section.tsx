import { motion } from 'framer-motion';
import React from 'react';

interface SectionProps {
  title?: string;
  subtitle?: string;
  className?: string;
  children: React.ReactNode;
  fullWidth?: boolean;
}

const Section: React.FC<SectionProps> = ({
  title,
  subtitle,
  className = '',
  children,
  fullWidth = false
}) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section className={`py-16 ${className}`}>
      {(title || subtitle) && (
        <div className="container mx-auto px-4 mb-10">
          <motion.div 
            className="text-center max-w-3xl mx-auto"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={containerVariants}
          >
            {title && (
              <motion.h2 
                className="text-3xl md:text-4xl font-heading font-bold mb-4"
                variants={itemVariants}
              >
                {title}
              </motion.h2>
            )}
            {subtitle && (
              <motion.p 
                className="text-gray-600 text-lg"
                variants={itemVariants}
              >
                {subtitle}
              </motion.p>
            )}
          </motion.div>
        </div>
      )}
      {fullWidth ? (
        children
      ) : (
        <div className="container mx-auto px-4">
          {children}
        </div>
      )}
    </section>
  );
};

export default Section;