import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ShoppingBag } from 'lucide-react';
import { Product } from '../../types/product';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="group"
    >
      <div className="relative overflow-hidden rounded-lg">
        <Link to={`/product/${product.id}`}>
          <div className="aspect-w-3 aspect-h-4 bg-gray-200 w-full">
            <img 
              src={product.images[0]} 
              alt={product.name}
              className="object-cover w-full h-[320px] transition-transform duration-500 group-hover:scale-105"
            />
          </div>
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {product.new && (
              <span className="bg-accent-500 text-white text-xs font-semibold px-2 py-1 rounded">
                NEW
              </span>
            )}
            {product.bestSeller && (
              <span className="bg-primary-600 text-white text-xs font-semibold px-2 py-1 rounded">
                BEST SELLER
              </span>
            )}
          </div>
          <div className="absolute inset-0 bg-black bg-opacity-20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <span className="bg-white text-gray-900 py-2 px-4 rounded-md font-medium transform translate-y-4 group-hover:translate-y-0 transition-transform">
              View Product
            </span>
          </div>
        </Link>
      </div>
      <div className="mt-4">
        <Link to={`/product/${product.id}`}>
          <h3 className="text-lg font-medium">{product.name}</h3>
        </Link>
        <div className="flex justify-between items-center mt-1">
          <span className="font-semibold">${product.price.toFixed(2)}</span>
          <div className="flex items-center gap-2">
            {product.colors.map((color, index) => (
              <div 
                key={index}
                className="w-4 h-4 rounded-full border border-gray-300"
                style={{ backgroundColor: color.hex }}
                title={color.name}
              />
            ))}
          </div>
        </div>
        <button className="mt-3 w-full flex items-center justify-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 rounded transition-colors">
          <ShoppingBag size={16} />
          <span>Quick Add</span>
        </button>
      </div>
    </motion.div>
  );
};

export default ProductCard;