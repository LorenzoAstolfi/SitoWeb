import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';

const NotFound: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-[80vh] flex flex-col items-center justify-center px-4 py-16"
    >
      <h1 className="text-9xl font-bold text-primary-600">404</h1>
      <h2 className="text-2xl md:text-3xl font-semibold mt-4 mb-6 text-center">
        Oops! Page Not Found
      </h2>
      <p className="text-gray-600 text-center max-w-md mb-8">
        The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
      </p>
      <Link
        to="/"
        className="flex items-center bg-primary-600 hover:bg-primary-700 text-white font-medium py-3 px-6 rounded-md transition-colors"
      >
        <ArrowLeft size={18} className="mr-2" />
        Back to Homepage
      </Link>
    </motion.div>
  );
};

export default NotFound;