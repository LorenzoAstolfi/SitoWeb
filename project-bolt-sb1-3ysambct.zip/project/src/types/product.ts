export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  images: string[];
  category: string;
  tags: string[];
  sizes: string[];
  colors: { name: string; hex: string }[];
  featured: boolean;
  new: boolean;
  bestSeller: boolean;
}