import { motion } from 'framer-motion';
import { ArrowRight, ShoppingBag, Truck, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';

import Banner from '../components/ui/Banner';
import Section from '../components/ui/Section';
import ProductGrid from '../components/ui/ProductGrid';
import { getFeaturedProducts, getNewProducts } from '../data/products';

const Home: React.FC = () => {
  const featuredProducts = getFeaturedProducts();
  const newProducts = getNewProducts();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Hero Banner */}
      <Banner
        title="Premium T-Shirts For The Modern You"
        subtitle="Elevate your everyday style with our premium collection of designer t-shirts"
        ctaText="Shop Collection"
        ctaLink="/shop"
        imageUrl="https://images.pexels.com/photos/1549200/pexels-photo-1549200.jpeg?auto=compress&cs=tinysrgb&w=1600"
        height="large"
      />

      {/* USP Section */}
      <Section className="bg-gray-50">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div 
            className="text-center p-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center">
              <ShoppingBag size={28} />
            </div>
            <h3 className="text-xl font-semibold mb-2">Premium Materials</h3>
            <p className="text-gray-600">
              Our t-shirts are crafted from the finest organic cotton for ultimate comfort and durability.
            </p>
          </motion.div>

          <motion.div 
            className="text-center p-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Truck size={28} />
            </div>
            <h3 className="text-xl font-semibold mb-2">Free Shipping</h3>
            <p className="text-gray-600">
              Enjoy free shipping on all orders over $50. Fast delivery to your doorstep.
            </p>
          </motion.div>

          <motion.div 
            className="text-center p-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center">
              <RefreshCw size={28} />
            </div>
            <h3 className="text-xl font-semibold mb-2">30 Day Returns</h3>
            <p className="text-gray-600">
              Not completely satisfied? Return your items within 30 days for a full refund.
            </p>
          </motion.div>
        </div>
      </Section>

      {/* Featured Products */}
      <Section 
        title="Featured Collection" 
        subtitle="Discover our most popular designs, crafted for style and comfort"
      >
        <ProductGrid products={featuredProducts} />
        <div className="mt-12 text-center">
          <Link 
            to="/shop" 
            className="inline-flex items-center text-primary-600 hover:text-primary-800 font-medium transition-colors"
          >
            View All Products <ArrowRight size={16} className="ml-2" />
          </Link>
        </div>
      </Section>

      {/* Collection Banner */}
      <Banner
        title="Limited Edition Artist Series"
        subtitle="Exclusive t-shirts featuring original artwork from renowned artists"
        ctaText="Shop Limited Editions"
        ctaLink="/shop"
        imageUrl="https://images.pexels.com/photos/5698851/pexels-photo-5698851.jpeg?auto=compress&cs=tinysrgb&w=1600"
        height="medium"
        position="left"
      />

      {/* New Arrivals */}
      <Section 
        title="New Arrivals" 
        subtitle="Be the first to wear our latest designs"
      >
        <ProductGrid products={newProducts} />
        <div className="mt-12 text-center">
          <Link 
            to="/shop" 
            className="inline-flex items-center text-primary-600 hover:text-primary-800 font-medium transition-colors"
          >
            View All Products <ArrowRight size={16} className="ml-2" />
          </Link>
        </div>
      </Section>

      {/* Newsletter */}
      <Section className="bg-primary-50">
        <div className="max-w-3xl mx-auto text-center">
          <motion.h2 
            className="text-3xl font-heading font-bold mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Join Our Newsletter
          </motion.h2>
          <motion.p 
            className="text-gray-600 mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Subscribe to receive updates, access to exclusive deals, and more.
          </motion.p>
          <motion.form 
            className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <input 
              type="email" 
              placeholder="Enter your email" 
              className="flex-grow px-4 py-3 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
              required
            />
            <button 
              type="submit" 
              className="bg-primary-600 hover:bg-primary-700 text-white font-medium py-3 px-6 rounded-md transition-colors"
            >
              Subscribe
            </button>
          </motion.form>
        </div>
      </Section>
    </motion.div>
  );
};

export default Home;