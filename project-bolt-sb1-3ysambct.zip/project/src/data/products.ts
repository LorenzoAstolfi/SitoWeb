import { Product } from '../types/product';

export const products: Product[] = [
  {
    id: 1,
    name: 'Classic Blue Hubb Tee',
    price: 29.99,
    description: 'Our signature t-shirt with the iconic Hubb logo. Made from 100% organic cotton for ultimate comfort and durability. This classic style features a regular fit and is perfect for everyday wear.',
    images: [
      'https://images.pexels.com/photos/1656684/pexels-photo-1656684.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1549200/pexels-photo-1549200.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'T-shirts',
    tags: ['classic', 'logo', 'blue', 'cotton'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Blue', hex: '#2563eb' },
      { name: 'Black', hex: '#000000' },
      { name: 'White', hex: '#ffffff' }
    ],
    featured: true,
    new: false,
    bestSeller: true
  },
  {
    id: 2,
    name: 'Urban Street Graphic Tee',
    price: 34.99,
    description: 'Express your urban style with our street-inspired graphic tee. Features a custom design by local artists and is printed on premium cotton fabric. Perfect for making a statement.',
    images: [
      'https://images.pexels.com/photos/3758054/pexels-photo-3758054.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/5114707/pexels-photo-5114707.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'T-shirts',
    tags: ['graphic', 'urban', 'street', 'premium'],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Black', hex: '#000000' },
      { name: 'White', hex: '#ffffff' }
    ],
    featured: false,
    new: true,
    bestSeller: false
  },
  {
    id: 3,
    name: 'Minimalist Logo Tee',
    price: 27.99,
    description: 'Less is more with our minimalist logo tee. Features a subtle embroidered Hubb logo on premium lightweight fabric. The perfect balance of style and comfort.',
    images: [
      'https://images.pexels.com/photos/5853936/pexels-photo-5853936.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/5853936/pexels-photo-5853936.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'T-shirts',
    tags: ['minimalist', 'embroidered', 'lightweight'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'White', hex: '#ffffff' },
      { name: 'Gray', hex: '#6b7280' },
      { name: 'Navy', hex: '#172554' }
    ],
    featured: true,
    new: false,
    bestSeller: false
  },
  {
    id: 4,
    name: 'Limited Edition Artist Collab',
    price: 49.99,
    description: 'Our exclusive artist collaboration series featuring original artwork from renowned artist James Chen. Each tee is individually numbered and comes with a certificate of authenticity.',
    images: [
      'https://images.pexels.com/photos/2102416/pexels-photo-2102416.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/794062/pexels-photo-794062.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Limited Edition',
    tags: ['limited', 'artist', 'collaboration', 'exclusive'],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Black', hex: '#000000' },
      { name: 'Royal Blue', hex: '#1d4ed8' }
    ],
    featured: true,
    new: true,
    bestSeller: false
  },
  {
    id: 5,
    name: 'Oversized Vintage Wash Tee',
    price: 39.99,
    description: 'Embrace the vintage look with our oversized, specially washed tee that gives you that perfectly worn-in feel from day one. Features a relaxed fit and ultra-soft fabric.',
    images: [
      'https://images.pexels.com/photos/2897531/pexels-photo-2897531.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/8386666/pexels-photo-8386666.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'T-shirts',
    tags: ['oversized', 'vintage', 'washed'],
    sizes: ['M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Washed Black', hex: '#1f2937' },
      { name: 'Washed Blue', hex: '#3b82f6' },
      { name: 'Washed Green', hex: '#10b981' }
    ],
    featured: false,
    new: false,
    bestSeller: true
  },
  {
    id: 6,
    name: 'Eco-Friendly Hemp Blend Tee',
    price: 42.99,
    description: 'Our sustainable tee made from a special blend of organic cotton and hemp. Environmentally friendly and incredibly durable with a unique texture that gets better with every wash.',
    images: [
      'https://images.pexels.com/photos/4066288/pexels-photo-4066288.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/4066293/pexels-photo-4066293.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Sustainable',
    tags: ['eco-friendly', 'hemp', 'sustainable', 'organic'],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Natural', hex: '#f5f5dc' },
      { name: 'Earth Brown', hex: '#8B4513' }
    ],
    featured: true,
    new: true,
    bestSeller: false
  }
];

export const getProductById = (id: number): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getFeaturedProducts = (): Product[] => {
  return products.filter(product => product.featured);
};

export const getNewProducts = (): Product[] => {
  return products.filter(product => product.new);
};

export const getBestSellers = (): Product[] => {
  return products.filter(product => product.bestSeller);
};