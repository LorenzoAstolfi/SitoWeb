import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

interface BannerProps {
  title: string;
  subtitle?: string;
  ctaText?: string;
  ctaLink?: string;
  imageUrl: string;
  overlay?: boolean;
  position?: 'left' | 'center' | 'right';
  textColor?: 'light' | 'dark';
  height?: 'small' | 'medium' | 'large' | 'full';
}

const Banner: React.FC<BannerProps> = ({
  title,
  subtitle,
  ctaText,
  ctaLink = '/shop',
  imageUrl,
  overlay = true,
  position = 'center',
  textColor = 'light',
  height = 'medium'
}) => {
  // Map height to tailwind classes
  const heightClass = {
    small: 'h-[300px]',
    medium: 'h-[500px]',
    large: 'h-[700px]',
    full: 'h-screen'
  }[height];

  // Map position to tailwind classes
  const positionClass = {
    left: 'justify-start text-left',
    center: 'justify-center text-center',
    right: 'justify-end text-right'
  }[position];

  // Map text color to tailwind classes
  const textColorClass = {
    light: 'text-white',
    dark: 'text-gray-900'
  }[textColor];

  return (
    <div 
      className={`relative overflow-hidden ${heightClass}`}
      style={{ backgroundImage: `url(${imageUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
    >
      {overlay && (
        <div className="absolute inset-0 bg-black bg-opacity-40" />
      )}
      <div className={`container mx-auto px-4 h-full flex items-center ${positionClass}`}>
        <div className="relative z-10 max-w-lg p-6">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className={`text-4xl md:text-5xl lg:text-6xl font-heading font-bold mb-4 ${textColorClass}`}
          >
            {title}
          </motion.h2>
          {subtitle && (
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className={`text-lg md:text-xl mb-6 ${textColorClass} opacity-90`}
            >
              {subtitle}
            </motion.p>
          )}
          {ctaText && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Link 
                to={ctaLink} 
                className="bg-primary-600 hover:bg-primary-700 text-white font-medium py-3 px-8 rounded-md transition-colors inline-block"
              >
                {ctaText}
              </Link>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Banner;