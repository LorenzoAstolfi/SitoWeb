import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

import Section from '../components/ui/Section';
import Banner from '../components/ui/Banner';

const About: React.FC = () => {
  const teamMembers = [
    {
      name: 'Alex Johnson',
      role: 'Founder & CEO',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      bio: 'Alex founded Hubb in 2020 with a vision to create premium t-shirts that combine style, comfort, and sustainability.'
    },
    {
      name: 'Sarah Chen',
      role: 'Creative Director',
      image: 'https://images.pexels.com/photos/3586798/pexels-photo-3586798.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      bio: 'With over 10 years in fashion design, Sarah brings her unique creative vision to every Hubb collection.'
    },
    {
      name: 'Marcus Lee',
      role: 'Head of Production',
      image: 'https://images.pexels.com/photos/2232981/pexels-photo-2232981.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      bio: 'Marcus ensures all Hubb products meet our high quality standards while maintaining ethical production practices.'
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Hero Banner */}
      <Banner
        title="Our Story"
        subtitle="Learn about our journey, values, and the people behind Hubb"
        imageUrl="https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=1600"
        height="medium"
      />

      {/* Our Story */}
      <Section>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-heading font-bold mb-6">The Hubb Story</h2>
            <p className="text-gray-600 mb-4">
              Hubb was born from a simple idea: create the perfect t-shirt that people would want to wear every day. In 2020, our founder Alex Johnson set out to revolutionize the t-shirt industry by focusing on three key principles: premium quality, timeless design, and sustainable practices.
            </p>
            <p className="text-gray-600 mb-4">
              What began as a small operation in Alex's garage has grown into a beloved brand with customers worldwide. Our commitment to quality has never wavered – each Hubb t-shirt is still crafted with the same attention to detail that defined our very first products.
            </p>
            <p className="text-gray-600">
              Today, we continue to push boundaries with innovative designs and sustainable materials while staying true to our core mission: creating premium t-shirts that make you look good, feel good, and do good.
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="rounded-lg overflow-hidden"
          >
            <img 
              src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Hubb team working together"
              className="w-full h-auto"
            />
          </motion.div>
        </div>
      </Section>

      {/* Our Values */}
      <Section className="bg-gray-50">
        <h2 className="text-3xl font-heading font-bold text-center mb-12">Our Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div 
            className="bg-white p-8 rounded-lg shadow-sm"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-full mb-6 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-4">Quality First</h3>
            <p className="text-gray-600">
              We never compromise on quality. From fabric selection to the final stitch, every detail matters in creating t-shirts that look great and last longer.
            </p>
          </motion.div>

          <motion.div 
            className="bg-white p-8 rounded-lg shadow-sm"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-full mb-6 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-4">Sustainability</h3>
            <p className="text-gray-600">
              We're committed to responsible practices that minimize our environmental impact, from using organic cotton to reducing waste in our production process.
            </p>
          </motion.div>

          <motion.div 
            className="bg-white p-8 rounded-lg shadow-sm"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-full mb-6 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.39-2.823 1.07-4" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-4">Timeless Design</h3>
            <p className="text-gray-600">
              We create designs that transcend trends, focusing on timeless aesthetics and versatility that keep your wardrobe fresh year after year.
            </p>
          </motion.div>
        </div>
      </Section>

      {/* Meet the Team */}
      <Section title="Meet Our Team" subtitle="The passionate people behind Hubb">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <motion.div 
              key={member.name}
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="relative mb-4 rounded-full overflow-hidden w-48 h-48 mx-auto">
                <img 
                  src={member.image} 
                  alt={member.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
              <p className="text-primary-600 font-medium mb-3">{member.role}</p>
              <p className="text-gray-600">{member.bio}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Commitments */}
      <Section className="bg-primary-50">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-heading font-bold mb-6">Our Commitments</h2>
            <p className="text-gray-600 mb-6">
              At Hubb, we believe in creating products that make a positive impact on both our customers and the world. Here's how we're working to make a difference:
            </p>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Check size={20} className="text-primary-600 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold mb-1">100% Organic Materials</h4>
                  <p className="text-gray-600">We use only certified organic cotton grown without harmful pesticides or fertilizers.</p>
                </div>
              </li>
              <li className="flex items-start">
                <Check size={20} className="text-primary-600 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold mb-1">Ethical Manufacturing</h4>
                  <p className="text-gray-600">All our products are made in facilities that provide fair wages and safe working conditions.</p>
                </div>
              </li>
              <li className="flex items-start">
                <Check size={20} className="text-primary-600 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold mb-1">Reduced Carbon Footprint</h4>
                  <p className="text-gray-600">We're constantly working to minimize our carbon emissions throughout our supply chain.</p>
                </div>
              </li>
              <li className="flex items-start">
                <Check size={20} className="text-primary-600 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold mb-1">Giving Back</h4>
                  <p className="text-gray-600">We donate 5% of our profits to environmental conservation efforts around the world.</p>
                </div>
              </li>
            </ul>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="rounded-lg overflow-hidden"
          >
            <img 
              src="https://images.pexels.com/photos/7262379/pexels-photo-7262379.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Sustainable cotton farming"
              className="w-full h-auto"
            />
          </motion.div>
        </div>
      </Section>
    </motion.div>
  );
};

export default About;