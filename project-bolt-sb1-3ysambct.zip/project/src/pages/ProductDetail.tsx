import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Check, 
  Truck, 
  RefreshCw, 
  Shield, 
  ChevronRight,
  Star,
  Heart
} from 'lucide-react';

import Section from '../components/ui/Section';
import ProductGrid from '../components/ui/ProductGrid';
import { getProductById, getBestSellers } from '../data/products';
import { useCart } from '../context/CartContext';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const productId = parseInt(id || '0');
  const product = getProductById(productId);
  const relatedProducts = getBestSellers().filter(p => p.id !== productId).slice(0, 4);
  
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-semibold mb-4">Product Not Found</h2>
        <p className="text-gray-600 mb-8">Sorry, the product you are looking for does not exist.</p>
        <Link 
          to="/shop" 
          className="bg-primary-600 text-white px-6 py-2 rounded-md hover:bg-primary-700 transition-colors"
        >
          Back to Shop
        </Link>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Please select a size');
      return;
    }
    
    addToCart(product, quantity, selectedSize);
    // Can add a notification here instead of navigation
    navigate('/shop');
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Breadcrumbs */}
          <div className="flex items-center text-sm text-gray-500 mb-8">
            <Link to="/" className="hover:text-primary-600 transition-colors">Home</Link>
            <ChevronRight size={14} className="mx-2" />
            <Link to="/shop" className="hover:text-primary-600 transition-colors">Shop</Link>
            <ChevronRight size={14} className="mx-2" />
            <span className="text-gray-700">{product.name}</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Images */}
            <div>
              <div className="bg-gray-100 rounded-lg overflow-hidden mb-4">
                <img 
                  src={product.images[selectedImage]} 
                  alt={product.name}
                  className="w-full h-auto object-cover"
                />
              </div>
              <div className="flex gap-4">
                {product.images.map((image, index) => (
                  <button 
                    key={index}
                    className={`border-2 rounded-md overflow-hidden w-20 h-20 ${
                      selectedImage === index ? 'border-primary-600' : 'border-transparent'
                    }`}
                    onClick={() => setSelectedImage(index)}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} - view ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Details */}
            <div>
              {product.new && (
                <span className="inline-block bg-accent-500 text-white text-xs font-semibold px-2 py-1 rounded mb-4">
                  NEW
                </span>
              )}
              <h1 className="text-3xl font-heading font-bold mb-2">{product.name}</h1>
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400 mr-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} fill="#FACC15" />
                  ))}
                </div>
                <span className="text-gray-500">42 reviews</span>
              </div>
              <p className="text-2xl font-semibold mb-6">${product.price.toFixed(2)}</p>
              <p className="text-gray-600 mb-8">{product.description}</p>

              {/* Colors */}
              <div className="mb-6">
                <h3 className="text-sm font-medium mb-2">Colors</h3>
                <div className="flex gap-3">
                  {product.colors.map((color, index) => (
                    <button 
                      key={index}
                      className="w-8 h-8 rounded-full border-2 border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                      style={{ backgroundColor: color.hex }}
                      title={color.name}
                    />
                  ))}
                </div>
              </div>

              {/* Sizes */}
              <div className="mb-8">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-sm font-medium">Size</h3>
                  <button className="text-sm text-primary-600 hover:text-primary-800 transition-colors">
                    Size Guide
                  </button>
                </div>
                <div className="flex flex-wrap gap-3">
                  {product.sizes.map((size) => (
                    <button 
                      key={size}
                      className={`min-w-[48px] h-10 px-3 border rounded-md text-sm font-medium transition-colors ${
                        selectedSize === size 
                          ? 'bg-primary-600 border-primary-600 text-white' 
                          : 'border-gray-300 text-gray-700 hover:border-gray-400'
                      }`}
                      onClick={() => setSelectedSize(size)}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity and Add to Cart */}
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <div className="flex border border-gray-300 rounded-md w-32">
                  <button 
                    className="w-10 h-12 flex items-center justify-center text-gray-600 hover:bg-gray-100"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    -
                  </button>
                  <input 
                    type="number" 
                    min="1" 
                    value={quantity} 
                    onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                    className="w-12 h-12 text-center border-x border-gray-300 focus:outline-none"
                  />
                  <button 
                    className="w-10 h-12 flex items-center justify-center text-gray-600 hover:bg-gray-100"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    +
                  </button>
                </div>
                <div className="flex-grow flex gap-3">
                  <button 
                    className="flex-grow bg-primary-600 hover:bg-primary-700 text-white font-medium py-3 px-6 rounded-md transition-colors"
                    onClick={handleAddToCart}
                  >
                    Add to Cart
                  </button>
                  <button className="w-12 h-12 flex items-center justify-center border border-gray-300 rounded-md hover:bg-gray-100 transition-colors">
                    <Heart size={20} />
                  </button>
                </div>
              </div>

              {/* Benefits */}
              <div className="border-t border-gray-200 pt-6 space-y-4">
                <div className="flex items-center">
                  <Truck size={20} className="text-primary-600 mr-3" />
                  <span>Free shipping on orders over $50</span>
                </div>
                <div className="flex items-center">
                  <RefreshCw size={20} className="text-primary-600 mr-3" />
                  <span>30-day return policy</span>
                </div>
                <div className="flex items-center">
                  <Shield size={20} className="text-primary-600 mr-3" />
                  <span>Quality guarantee</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Information Tabs */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="flex border-b border-gray-300 mb-8">
            <button className="text-primary-600 border-b-2 border-primary-600 px-6 py-3 font-medium">
              Description
            </button>
            <button className="text-gray-500 hover:text-gray-700 px-6 py-3 font-medium">
              Reviews (42)
            </button>
            <button className="text-gray-500 hover:text-gray-700 px-6 py-3 font-medium">
              Shipping & Returns
            </button>
          </div>
          <div className="max-w-3xl">
            <p className="text-gray-600 mb-4">
              {product.description}
            </p>
            <p className="text-gray-600 mb-4">
              Each t-shirt is made from high-quality, pre-shrunk 100% organic cotton, ensuring a comfortable fit that lasts wash after wash.
            </p>
            <h3 className="font-semibold text-lg mt-6 mb-2">Features:</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <Check size={18} className="text-primary-600 mr-2 mt-1 shrink-0" />
                <span>100% organic cotton for breathability and comfort</span>
              </li>
              <li className="flex items-start">
                <Check size={18} className="text-primary-600 mr-2 mt-1 shrink-0" />
                <span>Reinforced stitching for increased durability</span>
              </li>
              <li className="flex items-start">
                <Check size={18} className="text-primary-600 mr-2 mt-1 shrink-0" />
                <span>Pre-shrunk to maintain size and shape</span>
              </li>
              <li className="flex items-start">
                <Check size={18} className="text-primary-600 mr-2 mt-1 shrink-0" />
                <span>Tagless label for irritation-free comfort</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Related Products */}
      <Section 
        title="You Might Also Like" 
        subtitle="Customers who purchased this item also bought"
      >
        <ProductGrid products={relatedProducts} />
      </Section>
    </motion.div>
  );
};

export default ProductDetail;